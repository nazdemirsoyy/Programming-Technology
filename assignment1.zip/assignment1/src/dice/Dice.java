package dice;

public class Dice {
    
    private int rightValue;
    private int leftValue;

    public Dice(int rightValue, int leftValue) {
        this.rightValue = rightValue;
        this.leftValue = leftValue;
    }

    public int getValue() {
        return rightValue + leftValue;
    }

    
}
