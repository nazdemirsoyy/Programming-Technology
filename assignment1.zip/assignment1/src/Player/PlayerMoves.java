package Player;

import field.FieldProperty;
        
public interface PlayerMoves {
    
     /*
     * Takes a property field and build a house according to the player's owned property and total money
     */
    void buildHouse(FieldProperty field) throws NotEnoughMoneyException; 

    /*
     * takes a property field and buys a property according to the player's conditions
     */
    void buyProperty(FieldProperty field) throws NotEnoughMoneyException;

    Player getPlayer();

    void removeOwner();

    boolean isOwned(FieldProperty field);

    
}
