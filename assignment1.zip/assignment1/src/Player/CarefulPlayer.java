package Player;

import field.FieldProperty;

public class CarefulPlayer implements Strategy {

    private final PlayerMoves playerMove;
    private int amountOfMoneyForThisRound;
    private int currentRound = 0;

    public CarefulPlayer(Player player) {
        amountOfMoneyForThisRound = player.getMoney() / 2;
        playerMove = new PlayerMoveImplementations(player);
    }

    private boolean hasEnoughMoney() {
        return playerMove.getPlayer().getMoney() > amountOfMoneyForThisRound;  // amountOfMoneyForThisRound = player.getMoney() / 2;
    }

    /*
     * Careful player buys in a round only for at most half the amount of his money.
     * @param propertyField for the property field the player is on currently
     * throws NotEnoughMoneyException if player doesn't have enough money 
     */
    @Override
    public void playStrategy(FieldProperty propertyField) throws NotEnoughMoneyException {
        int round = playerMove.getPlayer().getRound();
        if (round > currentRound) {
            currentRound = round;
            amountOfMoneyForThisRound = playerMove.getPlayer().getMoney() / 2; // amount of money he can spend this round
        }

        if ((playerMove.getPlayer().getMoney() > amountOfMoneyForThisRound)) {
            if (playerMove.isOwned(propertyField) && hasEnoughMoney()) { //If he is the owner && has enough money -> build house
                playerMove.buildHouse(propertyField);
            } else if (hasEnoughMoney()) {          //If he can buy he buys
                playerMove.buyProperty(propertyField);
            }
        }
    }

    @Override
    public PlayerMoves getPlayerMove() {
        return playerMove;
    }
}

