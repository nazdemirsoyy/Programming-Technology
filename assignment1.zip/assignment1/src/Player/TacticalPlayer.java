package Player;

import field.FieldProperty;

public class TacticalPlayer implements Strategy {

    private final PlayerMoves playerMove;
    private int chance = 0;

    public TacticalPlayer(Player player) {
        playerMove = new PlayerMoveImplementations(player);
    }

    /*
     * Tactical Player skips each second chance when he could buy.
     * @param propertyField for the property field the player is on currently
     * throws NotEnoughMoneyException if player doesn't have enough money 
     */
    @Override
    public void playStrategy(FieldProperty propertyField) throws NotEnoughMoneyException {
        if (chance % 2 != 0) {
            if (playerMove.isOwned(propertyField)) {
                playerMove.buildHouse(propertyField);
            } else {
                playerMove.buyProperty(propertyField);
            }
        }
        chance++;
    }

    @Override
    public PlayerMoves getPlayerMove() {
        return playerMove;
    }
}
