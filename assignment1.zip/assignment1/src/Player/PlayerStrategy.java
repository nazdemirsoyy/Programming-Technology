package Player;

   public class PlayerStrategy {

    public static Strategy createStrategy(Player player, StrategyTypes strategyTypes) throws Exception {
        switch (strategyTypes) {
            case GREEDY:
                return createGreedy(player);
            case CAREFUL:
                return createCareful(player);
            case TACTICAL:
                return createTactical(player);
            default:
                throw new Exception("Unknown Player Type");
        }
    }

    public static Strategy createGreedy(Player player) {
        return new GreedyPlayer(player);
    }

    public static Strategy createCareful(Player player) {
        return new CarefulPlayer(player);
    }

    public static Strategy createTactical(Player player) {
        return new TacticalPlayer(player);
    }
}

