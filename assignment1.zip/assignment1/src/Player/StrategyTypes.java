
package Player;

public enum StrategyTypes {
    TACTICAL, GREEDY, CAREFUL
}
