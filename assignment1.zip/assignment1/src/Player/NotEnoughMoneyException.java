package Player;

public class NotEnoughMoneyException extends Exception {
    public NotEnoughMoneyException() {
        super("Player doesn't have enough money.");
    }
}
