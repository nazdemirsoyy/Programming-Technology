package Player;

import field.FieldProperty;

public interface Strategy {

    void playStrategy(FieldProperty propertyField) throws NotEnoughMoneyException;

    PlayerMoves getPlayerMove();

}
