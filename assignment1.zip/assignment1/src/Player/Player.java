package Player;

import field.FieldProperty;


public class Player implements Strategy {

    private final String name;
    private final Strategy strategy;
    private final StrategyTypes strategyTypes;
    private int money = 10000; //initial value
    private int currentPosition = 0;
    private int round = 0;

    public Player(String name, StrategyTypes playerStrategy) throws Exception {
        this.name = name;
        this.strategyTypes = playerStrategy;
        this.strategy = PlayerStrategy.createStrategy(this, playerStrategy);
    }

    public StrategyTypes getStrategyTypes() {
        return strategyTypes;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    /*
      Checks if player has the money then pay the price if it can be paid.
      throw NotEnoughMoneyException if player doesn't have enough money.
    */
    public void payMoney(int price) throws NotEnoughMoneyException {
        if (getMoney() > price) {
            setMoney(getMoney() - price);
        } else {
            throw new NotEnoughMoneyException();
        }
    }

    public void addMoney(int money) {
        setMoney(getMoney() + money);
    }

    public String getName() {
        return name;
    }

    /*
      If a player loses all of it's property become available.
      throw NotEnoughMoneyException if player doesn't have enough money.
    */
    @Override
    public void playStrategy(FieldProperty propertyField) throws NotEnoughMoneyException {
        try {
            strategy.playStrategy(propertyField);
        } catch (NotEnoughMoneyException ex) {
            strategy.getPlayerMove().removeOwner();
            throw ex;
        }
    }

    /*
      Gets the player choice according to its strategy and the field.
    */
    @Override
    public PlayerMoves getPlayerMove() {
        return strategy.getPlayerMove();
    }

    /*
     Keep track of the player position
     Keeps track of the round and the last position the player was on. Then increases it and saves the new position
     @param inc            total number of steps the player moved.
     @param numberOfFields to make sure the player is not out of the board.
     @return currentPosition : new saved position
    */
    public int increasePosition(int inc, int numberOfFields) {
        int newPosition = (currentPosition + inc) % numberOfFields;
        if (newPosition < currentPosition) {
            round++;
        }
        currentPosition = newPosition;
        return currentPosition;
    }

    public int getRound() {
        return round;
    }

    @Override
    public String toString() {
        return getName();
    }
}
