package Player;

import field.FieldProperty;
import java.util.ArrayList;
import java.util.List;


public class PlayerMoveImplementations implements PlayerMoves{
    
    private final Player player;
    private final List<FieldProperty> ownedFields = new ArrayList<>();

    public PlayerMoveImplementations(Player player) {
        this.player = player;
    }

    public Player getPlayer() {
        return player;
    }

    /**
     * Checks is player is the owner and allows him/her to buy a house by subtracting house price from his money
     * and setting the field to have a house.
     *
     * @param field The field the player stepped on.
     * @throws NotEnoughMoneyException if player doesn't have enough money -> loses
     */
    @Override
    public void buildHouse(FieldProperty field) throws NotEnoughMoneyException {
        if (field.getOwner() == player) {
            player.payMoney(4000);
            field.setHouseBuilt(true);
        }
    }

    /**
     * If property has no owner and player steps in field then the field
     * is added to player's ownership list and subtract 1000 from his total money
     *
     * @param field field type
     * @throws NotEnoughMoneyException if player doesn't have enough money -> loses
     */
    @Override
    public void buyProperty(FieldProperty field) throws NotEnoughMoneyException {
        if (field.getOwner() == null) {
            ownedFields.add(field);
            player.payMoney(1000);
            field.setOwner(player);
        }
    }

    public void removeOwner() {
        for (FieldProperty field : ownedFields) {
            field.setOwner(null);
        }
    }

    public boolean isOwned(FieldProperty field) {
        return ownedFields.contains(field);
    }

    
}
