package Player;

import field.FieldProperty;


public class GreedyPlayer implements Strategy {

    private final PlayerMoves playerMove;

    public GreedyPlayer(Player player) {
        playerMove = new PlayerMoveImplementations(player);
    }

    /*
     * If he steps on an unowned property, or his own property without a house, he 
     * starts buying it, if he has enough money for it.
     * @param propertyField for the property field the player is on currently
     * throws NotEnoughMoneyException if player doesn't have enough money 
     */
    @Override
    public void playStrategy(FieldProperty propertyField) throws NotEnoughMoneyException {
        if (playerMove.isOwned(propertyField) && propertyField.getOwner() == null) {
            playerMove.buildHouse(propertyField);
        } else {
            playerMove.buyProperty(propertyField);
        }
    }

    @Override
    public PlayerMoves getPlayerMove() {
        return playerMove;
    }
}
