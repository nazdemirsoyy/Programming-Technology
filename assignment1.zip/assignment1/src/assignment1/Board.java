package assignment1;

import Player.Player;
import Player.NotEnoughMoneyException;
import dice.Dice;
import field.field;
import field.FieldLucky;
import field.FieldProperty;
import field.FieldService;
import Player.StrategyTypes;
        
        
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

        
public class Board {
    
    private final List<Player> players = new ArrayList<>();
    private final List<field> fields = new ArrayList<>();
    private final List<Player> losers = new ArrayList<>(); 
    
    /*
      Returns the second loser from losers list.
    */
    public void play(Path path) {
        System.out.println(path.getFileName());
        try {
            List<String> lines = init(path);
            playTheGame(lines);

            if (losers.size() > 1) {
                System.out.println("Second loser: " + losers.get(1));
            } else if (losers.size() == 1 && players.size() == 1) {
                System.out.println(losers.get(0));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    /*
      Goes through the players strategies. If the strategy is between Greedy, Careful, or Tactical -> Calls the
      strategy type from Enum StrategyType
    */
    private StrategyTypes getStrategyType(String type) throws Exception {
        switch (type) {
            case "greedy":
                return StrategyTypes.GREEDY;
            case "careful":
                return StrategyTypes.CAREFUL;
            case "tactical":
                return StrategyTypes.TACTICAL;
            default:
                throw new Exception("Not a valid Type");
        }
    }

    /*
      Reads the dice numbers then checks if player loses
      @param lines All the lines of the file
     */

    private void playTheGame(List<String> lines) throws Exception {
        int diceIndex = fields.size() + players.size() + 3;

        if (diceIndex + 1 > lines.size() || (fields.size() < 1) || (players.size() < 1)) {
            System.out.println("No moves defined!");
            return;
        }

        for (int index = diceIndex + 1; index < lines.size(); index++) {
            String[] values = lines.get(index).split(" ");
            Dice dice = new Dice(
                    Integer.parseInt(values[2]),
                    Integer.parseInt(values[3])
            );
            // If player is still playing (in players list) and loses, player
            // is added to the losers list and removed from players list
            findPlayer(values[0], getStrategyType(values[1])).ifPresent(player -> {
                try {
                    playOneTurnWithPlayer(player, dice);
                } catch (NotEnoughMoneyException ex) {
                    losers.add(player);
                    players.remove(player);
                }
            });

            if (players.size() <= 1) {
                break;
            }
        }
    }

    /*
      Gets the number passed as numbers of fields and pass the players in
      the players list and the fields in fields list
      @param path Path of file read from
      @return lines read
      @throws EmptyFileException
     */
    private List<String> init(Path path) throws Exception {
        List<String> lines = Files.readAllLines(path);
        if (!lines.isEmpty()) {
            int numberOfFields = Integer.parseInt(lines.get(0));
            fillFieldsList(lines, numberOfFields);
            fillPlayersList(lines, numberOfFields);
        } else {
            throw new EmptyFileException();
        }
        return lines;
    }

    /*
      Makes sure that player playing is the same player in the index of the players list.
      Not to deal with NullPointerException then return player can be/can't be found in list
      @param playerName   Player's turn in move
      @param strategyType Player's strategy type
      @return player list can be empty or not
    */
    private Optional<Player> findPlayer(String playerName, StrategyTypes strategyType) {
        for (Player player : players) {
            if (player.getName().equals(playerName) && (player.getStrategyTypes() == strategyType)) {
                return Optional.of(player);
            }
        }
        return Optional.empty();
    }

    /*
      Reads in the player's name and strategy line by line depending on the number of players given.
      @param lines          Number of players given
      @param numberOfFields Passed to inform the program to read after those numbers of lines.
     */
    private void fillPlayersList(List<String> lines, int numberOfFields) throws Exception {
        if (fields.isEmpty()) throw new Exception("No fields found");
        int numberOfPlayersIndex = Integer.parseInt(lines.get(numberOfFields + 1));
        for (int index = numberOfFields + 2;
             index <= numberOfFields + numberOfPlayersIndex + 1;
             index++) {
            String[] player = lines.get(index).split(" ");
            switch (player[1]) {
                case "greedy":
                    players.add(new Player(player[0], StrategyTypes.GREEDY));
                    break;
                case "careful":
                    players.add(new Player(player[0], StrategyTypes.CAREFUL));
                    break;
                case "tactical":
                    players.add(new Player(player[0], StrategyTypes.TACTICAL));
                    break;
            }
        }
    }

    /*
      Read lines of fields according to a given number and defines them as property, service, or lucky fields
      @param lines          Lines of fields read
      @param numberOfFields Number passed to give number of fields
    */

    private void fillFieldsList(List<String> lines, int numberOfFields) throws Exception {
        for (int index = 1; index < numberOfFields; index++) {
            String[] fieldTypes = lines.get(index).split(" ");
            switch (fieldTypes[0]) {
                case "property":
                    fields.add(new FieldProperty());
                    break;
                case "service":
                    fields.add(new FieldService(Integer.parseInt(fieldTypes[1])));
                    break;
                case "lucky":
                    fields.add(new FieldLucky(Integer.parseInt(fieldTypes[1])));
                    break;
                default:
                    throw new Exception("No field defined! ");
            }
        }

    }

    /*
     Keep track of the player's position after rolling the dice and performs action according to which field the
     player stepped on
    */
    private void playOneTurnWithPlayer(Player player, Dice rolledDice) throws NotEnoughMoneyException {
        int position = player.increasePosition(rolledDice.getValue() - 1, fields.size());
        field field = fields.get(position);
        field.playerStepped(player);
    }
       
}
