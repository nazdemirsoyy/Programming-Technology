package assignment1;

import java.nio.file.Paths;

public class Assignment1 {

    public static void main(String[] args) throws Exception  {
        Board game1 = new Board();
        game1.play(Paths.get("Game1.txt"));

        Board game2 = new Board();
        game2.play(Paths.get("Game2.txt"));

        Board game3 = new Board();
        game3.play(Paths.get("Game3.txt"));

        Board game4 = new Board();
        game4.play(Paths.get("Game4.txt"));

        Board game5 = new Board();
        game5.play(Paths.get("Game5.txt"));
         
    }
    
}
