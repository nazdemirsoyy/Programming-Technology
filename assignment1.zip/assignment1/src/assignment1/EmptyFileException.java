package assignment1;

/**
 *
 * @author Acer
 */

public class EmptyFileException extends Exception {
       
    public EmptyFileException() {
        super("File is Empty!");
    }

}
