package field;

import Player.Player;
import Player.NotEnoughMoneyException;



public class FieldProperty implements field{
    
    private final Step propertyFieldStep;
    private Player owner;
    private boolean houseBuilt = false;

    public FieldProperty() {
        propertyFieldStep = new PropertyFieldStep(this);
    }

    public boolean isOwner(Player player) {
        return owner == player;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player player) {
        owner = player;
    }

    public boolean isHouseBuilt() {
        return houseBuilt;
    }

    public void setHouseBuilt(boolean houseBuilt) {
        this.houseBuilt = houseBuilt;
    }

    /*
     Calls doStep method from Step class to perform property step action.
     Calls player strategy to buy/noy buy property according to player's strategy.
     */
    @Override
    public void playerStepped(Player player) throws NotEnoughMoneyException {
        propertyFieldStep.doStep(player);
        player.playStrategy(this);
    }

    
    
}
