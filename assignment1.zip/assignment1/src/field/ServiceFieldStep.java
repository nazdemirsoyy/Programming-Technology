package field;

import Player.Player;
import Player.NotEnoughMoneyException;


public class ServiceFieldStep implements Step {
    
    private final FieldService fieldService;

    public ServiceFieldStep(FieldService fieldService) {
        this.fieldService = fieldService;
    }

    /*
        Gets the service price and subtracts it from player's money
    */
    @Override
    public void doStep(Player player) throws NotEnoughMoneyException {
        player.payMoney(fieldService.getServicePrice());
    }

    
}
