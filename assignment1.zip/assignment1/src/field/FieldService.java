package field;

import Player.Player;
import Player.NotEnoughMoneyException;


public class FieldService implements field{
    
    private int servicePrice;
    private Step serviceFieldStep;

    public FieldService(int servicePrice) {
        this.servicePrice = servicePrice;
        serviceFieldStep = new ServiceFieldStep(this) {};
    }

    public int getServicePrice() {
        return servicePrice;
    }

    /*
        Calls doStep to perform service step action from Step class
    */
    @Override
    public void playerStepped(Player player) throws NotEnoughMoneyException {
        serviceFieldStep.doStep(player);
    }

}
