package field;

import Player.Player;
import Player.NotEnoughMoneyException;

public class PropertyFieldStep implements Step{
    
    private final FieldProperty fieldProperty;

    public PropertyFieldStep(FieldProperty fieldProperty) {
        this.fieldProperty = fieldProperty;
    }

    /*
     Checks if the property has an owner and that it's not the player passed.
     Checks if there is a house built to charge the player to pay it's owner. Otherwise player buys property.
    */
    @Override
    public void doStep(Player player) throws NotEnoughMoneyException {
        if (fieldProperty.getOwner() != null && !fieldProperty.isOwner(player)) {
            if (fieldProperty.isHouseBuilt()) {
                player.payMoney(2000);
                fieldProperty.getOwner().addMoney(2000);
            } else {
                player.payMoney(500);
                fieldProperty.getOwner().addMoney(500);
            }
        }
    }

    
}
