package field;

import Player.Player;
import Player.NotEnoughMoneyException;


public interface Step {

    /*
        Decide what should the player 
        according to the field the player is on currently.
    */
    
    void doStep(Player player) throws NotEnoughMoneyException;
    
}
