package field;

import Player.Player;



public class LuckyFieldStep implements Step {
    
    private final FieldLucky fiedlLucky;

    public LuckyFieldStep(FieldLucky fiedlLucky) {
        this.fiedlLucky = fiedlLucky;
    }

    /*
         Gets lucky field value and adds it to the player's money
     */
    @Override
    public void doStep(Player player) {
        player.addMoney(fiedlLucky.getLuckyValue());
    }

    
}
