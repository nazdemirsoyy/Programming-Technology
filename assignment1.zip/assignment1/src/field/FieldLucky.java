package field;

import Player.Player;
import Player.NotEnoughMoneyException;
           
public class FieldLucky implements field{
   

    private final int luckyValue;
    private final Step step;

    public FieldLucky(int luckyValue) {
        this.luckyValue = luckyValue;
        step = new LuckyFieldStep(this);
    }

    public int getLuckyValue() {
        return luckyValue;
    }

    /*
      Calls doStep to perform lucky step action from Step class
    */
    @Override
    public void playerStepped(Player player) throws NotEnoughMoneyException {
        step.doStep(player);
    }
 
}
