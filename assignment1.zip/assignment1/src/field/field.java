package field;

import Player.Player;
import Player.NotEnoughMoneyException;

public interface field {
    /*
        Gets field player stepped on
    */
    void playerStepped(Player player) throws NotEnoughMoneyException;

}
