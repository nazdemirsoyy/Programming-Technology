/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Game;

/**
 *
 * @author Acer
 */
public class TronMain {
       public static void main(String[] args) {
           try{
                GameGUI gui = new GameGUI();
           }catch(Exception ex)
           {
               System.out.println("EXCEPTION: "+ ex.getMessage());
           }

    }

    
    
}
