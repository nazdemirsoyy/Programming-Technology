/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Game;

/**
 * DIRECTION ENUMERATION 
 * @author Acer
 */
public enum Direction {
   U,D,L,R,Z;
}
