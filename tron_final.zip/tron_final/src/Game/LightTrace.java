/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Game;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Acer
 */
public class LightTrace extends Sprite {
       // positions of the start and end of the line
	private int x2;
	private int y2;
        public static int size=5;
        
    /**
     * creates the lightTrace instance also calls the sprite constructor and sves the width and hieght as x2 and y2
     * @param x
     * @param y
     * @param width
     * @param height
     * @param color 
     */
    public LightTrace(int x, int y, int width, int height,Color color) {
        super(x,y,width,height,null,color);
        this.x2 = width;
        this.y2 = height;   
    }
    
   /**
    * draws the line 
    */
    
    public void draw(Graphics gc) {
        gc.setColor(color);
        gc.drawRect(this.x, this.y, this.width, this.height);             
    }
    
    public int getX1() {return x;}

    public void setX1(int x1) {this.x = x1;}

    public int getY1() {return y;}

    public void setY1(int y1) {this.y = y1;}

    public int getX2() {return x2;}

    public void setX2(int x2) {this.x2 = x2;}

    public int getY2() {return y2;}

    public void setY2(int y2) {this.y2 = y2;}
    
    //checks if the line is vertical
    public boolean isVertical() {return (x == x2);}  
} 

