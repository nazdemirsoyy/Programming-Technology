CREATE DATABASE HighScoreDB;

CREATE TABLE HIGHSCORES (
	TIMESTAMP timestamp, 
    Name varchar(255), 
    SCORE int
);

select * from HIGHSCORES;