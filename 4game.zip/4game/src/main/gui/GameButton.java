package main.gui;

/**
 *
 * @author Acer
 */

import javax.swing.*;

public class GameButton extends JButton {
    private final int row;
    private final int column;


    public GameButton(int row, int column) {
        this.row = row;
        this.column = column;
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }
}
