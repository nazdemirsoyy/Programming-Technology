package main;

/**
 *
 * @author Acer
 */

import main.gui.FourGameFrame;
import main.logic.FourGameLogic;

import javax.swing.*;

public class Main {

    private static final String NIMBUS_THEME = "Nimbus"; //2D vector graphics to draw the (UI)

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            applyNimbusTheme();

            new FourGameFrame(new FourGameLogic()).setVisible(true);
        });
    }

    private static void applyNimbusTheme() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if (info.getName().equals(NIMBUS_THEME)) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }

        }
        catch (Exception exception) {
            System.out.println("Failed to use Nimbus Theme. Exception message: " + exception);
        }
    }
}
